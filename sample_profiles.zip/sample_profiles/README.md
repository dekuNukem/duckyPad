## duckyPad Sample Profiles

To use in duckyPad, copy them to the root of a FAT32-formatted SD card.

See [this guide](/getting_started.md) for more detailed instructions.

https://github.com/dekuNukem/duckyPad/blob/master/getting_started.md