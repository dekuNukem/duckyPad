## duckyPad Sample Profiles

To use in duckyPad, copy all the folders here to the root of a FAT32-formatted SD card.

See [this guide](https://github.com/dekuNukem/duckyPad/blob/master/getting_started.md) for more detailed instructions.
