duckyPad SD card

All your scripts and settings are stored here!

--------------------

To backup, make a copy of everything here.

To restore, format this card in FAT/FAT32, copy everything back.

--------------------

See this guide for details:

https://github.com/dekuNukem/duckyPad/blob/master/getting_started.md