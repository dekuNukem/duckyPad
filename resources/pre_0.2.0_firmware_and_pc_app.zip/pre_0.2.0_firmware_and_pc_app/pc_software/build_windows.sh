pyinstaller.exe --noconsole --icon=icon.ico duckypad_config.py

# --onefile 